"residuals.MCMCglmm"<-function(object, type = c("deviance", "pearson", "working",
                                "response", "partial"), ...){
                     stop("residuals not yet implemented for MCMCglmm objects")
}

